import { Application } from '@nativescript/core';
import { registerElement } from '@nativescript/core';

Application.run({ moduleName: 'app-root' });